
         import { Link } from "react-scroll"


export default function Footer() {
  const currentYear = new Date().getFullYear()

  return (
    <footer id="contacts" className="bg-black text-white">
      <div className="container mx-auto px-4 py-12">
        {/* Grid Layout */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-10 md:gap-16 text-left">
       <div className="space-y-6">
  <a href="/" className="flex items-center space-x-3 group">
    {/* Logo Image */}
    <img
      src="/icon.jpg" // <- replace with your actual image path
      alt="Infravue Logo"
      className="w-12 h-12 sm:w-14 sm:h-14 object-cover rounded-full shadow-md transition-transform duration-300 group-hover:scale-105"
    />

    {/* Brand Name */}
    <span className="text-white font-bold text-xl sm:text-4xl lg:text-5xl font-economica tracking-wide transition-colors duration-300 group-hover:text-emerald-300">
      INFRAVUE
    </span>
  </a>

  {/* Address */}
  <p className="text-gray-400 text-xl sm:2xl font-bold">
    📍 10-3-347, Abhyudaya Nagar colony, Gandipet Mandal, RR District
  </p>

  {/* Tagline */}
  <p className="text-gray-300 text-base leading-relaxed">
    Shaping the future of spaces with innovation, creativity, and flawless execution across India.
  </p>
</div>

          <div className="space-y-2">
  <h4 className="text-lg font-semibold mb-4 text-white">Quick Links</h4>
  <ul className="space-y-3">
    <li>
      <Link
        to="aboutus"
        smooth={true}
        duration={600}
        offset={-50} // adjust if you have a fixed navbar
        className="text-gray-300 transition-all duration-300 hover:translate-x-1 block cursor-pointer"
      >
        Who Are We
      </Link>
    </li>
    <li>
      <Link
        to="domains"
        smooth={true}
        duration={600}
        offset={-50}
        className="text-gray-300transition-all duration-300 hover:translate-x-1 block cursor-pointer"
      >
        Domains
      </Link>
    </li>
    <li>
      <Link
        to="expertise"
        smooth={true}
        duration={600}
        offset={-50}
        className="text-gray-300 transition-all duration-300 hover:translate-x-1 block cursor-pointer"
      >
        Why Trust Us?
      </Link>
    </li>
    <li>
      <Link
        to="projects"
        smooth={true}
        duration={600}
        offset={-50}
        className="text-gray-300  transition-all duration-300 hover:translate-x-1 block cursor-pointer"
      >
        Work Experience
      </Link>
    </li>
    <li>
      <Link
        to="partners"
        smooth={true}
        duration={600}
        offset={-50}
        className="text-gray-300  transition-all duration-300 hover:translate-x-1 block cursor-pointer"
      >
        Partners
      </Link>
    </li>
  </ul>
</div>

          <div className="space-y-2">
            <h4 className="text-lg font-semibold mb-4 text-white">Business Verticals</h4>
            <ul className="space-y-3">
              <li>
                <a
                  href="#"
                  className="text-gray-300 transition-all duration-300 hover:translate-x-1 block"
                >
                  Corporations
                </a>
              </li>
              <li>
                <a
                  href="#"
                  className="text-gray-300  transition-all duration-300 hover:translate-x-1 block"
                >
                  Offices
                </a>
              </li>
              <li>
                <a
                  href="#"
                  className="text-gray-300  transition-all duration-300 hover:translate-x-1 block"
                >
                  Hospitals
                </a>
              </li>
              <li>
                <a
                  href="#"
                  className="text-gray-300  transition-all duration-300 hover:translate-x-1 block"
                >
                  Restaurants
                </a>
              </li>
              <li>
                <a
                  href="#"
                  className="text-gray-300  transition-all duration-300 hover:translate-x-1 block"
                >
                  Institutions
                </a>
              </li>
            </ul>
          </div>

          <div className="space-y-4">
            <h4 className="text-lg font-semibold mb-4">Connect With Us</h4>
      <div className="flex items-start space-x-4">
  {/* Facebook */}
  <a 
    href="https://www.instagram.com/infra_vue/?igsh=MWJucTAwOTcwdHM4dQ%3D%3D#" 
    target="_blank" 
    rel="noopener noreferrer"
    className="hover:scale-110 transition-all duration-300 p-2 rounded-lg hover:bg-white/10"
  >
    <img 
      src="/Images/Socials/instagram.png" 
      alt="Facebook" 
      className="w-8 h-8 object-contain"
    />
  </a>


  {/* WhatsApp */}
  <a 
    href="https://wa.me/917478075444" 
    target="_blank" 
    rel="noopener noreferrer"
    className="hover:scale-110 transition-all duration-300 p-2 rounded-lg hover:bg-white/10"
  >
    <img 
      src="/Images/Socials/whatsapp.png" 
      alt="WhatsApp" 
      className="w-8 h-8 object-contain"
    />
  </a>
</div>

            <div className="text-gray-300 text-xl font-bold space-y-2">
              <p className="hover:text-emerald-300 transition-colors duration-300">info@infravueinterior.com</p>
              <p className="hover:text-emerald-300 transition-colors duration-300">+91 7478075444</p>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-700 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-gray-400 text-sm">&copy; {currentYear} Infravue. All rights reserved.</p>
          <div className="flex space-x-6 mt-4 md:mt-0">
            <a href="#" className="text-gray-400 hover:text-emerald-300 text-sm transition-colors duration-300">
              Privacy Policy
            </a>
            <a href="#" className="text-gray-400 hover:text-emerald-300 text-sm transition-colors duration-300">
              Terms of Service
            </a>
            <a href="#" className="text-gray-400 hover:text-emerald-300 text-sm transition-colors duration-300">
              Cookie Policy
            </a>
          </div>
        </div>
      </div>
    </footer>
  )
}
