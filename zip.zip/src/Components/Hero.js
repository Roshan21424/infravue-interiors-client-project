"use client"

import { useEffect, useState } from "react"
import { motion } from "framer-motion"

export default function InfravueBanner() {
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    setIsVisible(true)
  }, [])

  const stats = [
    { value: "20+", label: "Projects Delivered" },
    { value: "5", label: "States Covered" },
  ]

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { opacity: 1, transition: { staggerChildren: 0.1 } },
  }

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: { y: 0, opacity: 1, transition: { duration: 0.5 } },
  }

  return (
    <section id="aboutus" className="py-8 md:py-16 relative overflow-hidden bg-white text-gray-900">
      {/* Background gradients (subtle architectural tones) */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none">
        <div className="absolute top-0 left-0 w-1/3 h-1/3 bg-gradient-to-br from-gray-200/20 to-transparent rounded-full blur-3xl -translate-x-1/2 -translate-y-1/2"></div>
        <div className="absolute bottom-0 right-0 w-1/2 h-1/2 bg-gradient-to-tl from-rose-200/20 to-transparent rounded-full blur-3xl translate-x-1/4 translate-y-1/4"></div>
      </div>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10 max-w-7xl">
        <motion.div initial="hidden" animate={isVisible ? "visible" : "hidden"} variants={containerVariants}>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 md:gap-12 items-start">
            {/* Left Text Content */}
            <motion.div
              variants={itemVariants}
              className="flex flex-col justify-start space-y-4 md:space-y-6 text-left"
            >
              <h2 className="text-lg sm:text-xl md:text-2xl lg:text-3xl xl:text-4xl leading-tight">
                <span className="font-extrabold font-economica text-2xl sm:text-3xl md:text-4xl lg:text-5xl xl:text-6xl text-[#FF0066] block mb-2">
                  Infravue
                </span>
                <span className="text-base sm:text-lg md:text-xl lg:text-2xl">
                  — Designing, Styling & Building Spaces That Inspire
                </span>
              </h2>

              <div className="text-sm sm:text-base md:text-lg lg:text-xl space-y-3 text-gray-700 font-light leading-relaxed">
                <p>
                  At Infravue, we bring your vision to life with world-class{" "}
                  <span className="font-medium text-[#239BA7] uppercase">interior designing & construction</span>{" "}
                  services. From offices and corporates to restaurants and hospitals, we craft timeless spaces across
                  India.
                </p>
                <p>
                  With decades of experience and mastery in{" "}
                  <span className="font-medium text-[#239BA7] uppercase">all styles & aesthetics</span>, we design,
                  style, and build interiors that reflect your brand and inspire everyone who walks in.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 sm:gap-4 mt-4">
                {stats.map((stat, index) => (
                  <div key={index} className="rounded-lg p-3 md:p-4 text-center sm:text-left">
                    <div className="text-lg sm:text-xl md:text-2xl lg:text-3xl xl:text-4xl font-bold text-[#FE7743] mb-1">
                      {stat.value}
                    </div>
                    <div className="text-xs md:text-sm text-gray-600 font-medium uppercase tracking-wide">
                      {stat.label}
                    </div>
                  </div>
                ))}
              </div>

              <div className="mt-4 md:mt-6">
                <button className="group relative px-4 sm:px-6 py-2 md:py-2.5 bg-gray-900 text-white rounded-full hover:bg-gray-700 transition-all duration-300 text-sm md:text-base">
                  <span className="relative z-10 group-hover:mr-2 transition-all duration-300">
                    Let's Build Your Vision
                  </span>
                  <span className="relative z-10 opacity-0 group-hover:opacity-100 transition-all duration-300">→</span>
                </button>
                <p className="text-gray-500 text-xs md:text-sm mt-2 font-light">
                  Get in touch today to start your project.
                </p>
              </div>
            </motion.div>

            <motion.div variants={itemVariants} className="flex justify-center lg:justify-end mt-6 lg:mt-0">
              <div className="relative w-full max-w-[280px] sm:max-w-[350px] md:max-w-[400px] lg:max-w-[450px] h-[250px] sm:h-[300px] md:h-[350px] lg:h-[400px] xl:h-[500px] rounded-2xl overflow-hidden shadow-lg">
                <img
                  src="/Hero.jpg"
                  alt="Infravue Interior Design"
                  className="w-full h-full object-cover"
                  loading="lazy"
                />

                <div className="absolute bottom-3 md:bottom-5 left-3 md:left-5 text-white z-10 text-left">
                  <h3 className="text-base sm:text-lg md:text-xl font-light">
                    Spaces <span className="font-medium">Redefined</span>
                  </h3>
                  <p className="text-xs md:text-sm font-light tracking-wide">
                    Interior Design & Construction by Infravue
                  </p>
                </div>
              </div>
            </motion.div>
          </div>
        </motion.div>
      </div>
    </section>
  )
}
