import React, { useEffect, useRef } from "react";

export default function ParallaxScroll() {
  const textRef = useRef();

  useEffect(() => {
    const handleScroll = () => {
      const value = window.scrollY;
      if (textRef.current)
        textRef.current.style.transform = `translateY(${value * 0.5}px)`;
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const socials = [
    { name: "instagram", href: "https://www.instagram.com/infra_vue/?igsh=MWJucTAwOTcwdHM4dQ%3D%3D#" },
    { name: "whatsapp", href: "https://wa.me/917478075444" },
  ];

  return (
    <div id="home" className="relative w-full h-screen overflow-hidden text-white">
      {/* Background video */}
      <video
        src="/landing.mp4"   // <-- replace with your video path
        autoPlay
        muted
        loop
        playsInline
        className="absolute top-[-50px] left-0 w-full h-[120%] z-0 object-cover"
      />

      {/* Black overlay */}
      <div className="absolute top-0 left-0 w-full h-full bg-black/50 z-10"></div>

      {/* Main content */}
      <div
        ref={textRef}
        className="relative z-20 flex flex-col justify-center h-full max-w-6xl px-6 sm:px-12 text-left text-white"
      >
        <h1 className="text-3xl sm:text-5xl lg:text-8xl font-semibold py-4">
          YOUR
   
          <span className="uppercase font-extrabold rounded-xl   px-5 py-3 text-3xl sm:text-5xl lg:text-8xl ">
            SPACE
          </span>
          <span className="text-3xl sm:text-5xl lg:text-8xl mx-3 font-semibold">
            OUR
          </span>
          <span className="  uppercase font-extrabold   px-5 py-3 text-3xl sm:text-5xl lg:text-8xl ">
            Promise
          </span>
          <br />
        
        </h1>

        <p className="text-sm sm:text-base md:text-lg lg:text-xl text-gray-200 mb-6 sm:mb-8">
          Infravue transforms offices, corporations, hospitals, restaurants, and institutions
          into inspiring spaces with innovative design and flawless execution across India.
        </p>

        <div className="flex items-center space-x-4 sm:space-x-6">
          <p className="text-sm sm:text-lg font-light text-white/60 underline">Follow us:</p>
          {socials.map(({ name, href }) => (
            <a
              key={name}
              href={href}
              target="_blank"
              rel="noopener noreferrer"
              className="transition-all duration-300 hover:scale-110 opacity-70 hover:opacity-100"
            >
              <img
                src={`/Images/Socials/${name}.png`}
                alt={name}
                className="w-6 sm:w-8 h-6 sm:h-8"
              />
            </a>
          ))}
        </div>
      </div>
    </div>
  );
}
