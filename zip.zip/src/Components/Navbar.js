"use client"
import { useState } from "react"
import { Menu, X } from "lucide-react"

export default function Navbar() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  return (
    <nav className="fixed w-full z-50 backdrop-blur-md bg-black/40 border-b border-white/10 shadow-lg">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3 sm:py-4 lg:py-5">
        <div className="flex items-center justify-between">
  <a href="/" className="flex items-center space-x-3 group">
  {/* Logo Image */}
  <img
    src="/icon.jpg" // <- replace with your actual image path
    alt="Infravue Logo"
    className="w-12 h-12 sm:w-14 sm:h-14 object-cover rounded-full shadow-md transition-transform duration-300 group-hover:scale-105"
  />

  {/* Brand Name */}
  <span className="text-white font-bold text-xl sm:text-2xl lg:text-3xl font-economica tracking-wide transition-colors duration-300 group-hover:text-emerald-300">
    INFRAVUE
  </span>
</a>



          {/* Desktop Navigation */}
          <div className="hidden md:flex space-x-6 lg:space-x-10">
            <NavLink to="home">Home</NavLink>
            <NavLink to="aboutus">About Us</NavLink>
            <NavLink to="domains">Domains</NavLink>
            <NavLink to="projects">Projects</NavLink>
            <NavLink to="founder">Founder</NavLink>
            <NavLink to="contacts">Contacts</NavLink>
          </div>

          <div className="md:hidden">
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="text-white hover:text-emerald-400 transition-all duration-300 p-2 rounded-lg hover:bg-white/10 transform hover:scale-110"
              aria-label={isMenuOpen ? "Close menu" : "Open menu"}
            >
              {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {isMenuOpen && (
          <div className="md:hidden mt-4 bg-white/10 backdrop-blur-md rounded-xl p-4 shadow-xl border border-white/20 animate-fadeIn">
            <div className="flex flex-col space-y-4">
              <MobileNavLink to="home" onClick={() => setIsMenuOpen(false)}>
                Home
              </MobileNavLink>
              <MobileNavLink to="aboutus" onClick={() => setIsMenuOpen(false)}>
                About Us
              </MobileNavLink>
              <MobileNavLink to="domains" onClick={() => setIsMenuOpen(false)}>
                Domains
              </MobileNavLink>
              <MobileNavLink to="projects" onClick={() => setIsMenuOpen(false)}>
                Projects
              </MobileNavLink>
              <MobileNavLink to="founder" onClick={() => setIsMenuOpen(false)}>
                Founder
              </MobileNavLink>
              <MobileNavLink to="contacts" onClick={() => setIsMenuOpen(false)}>
                Contacts
              </MobileNavLink>
            </div>
          </div>
        )}
      </div>
    </nav>
  )
}

const NavLink = ({ to, children }) => (
  <a
    href={`#${to}`}
    className="relative text-white text-base lg:text-lg font-medium cursor-pointer transition-all duration-300 group hover:text-emerald-300 px-2 py-1 rounded-md hover:bg-white/5"
  >
    {children}
    <span className="absolute left-0 bottom-0 h-0.5 w-0 bg-gradient-to-r from-emerald-400 to-blue-500 transition-all duration-300 group-hover:w-full rounded-full"></span>
  </a>
)

const MobileNavLink = ({ to, onClick, children }) => (
  <a
    href={`#${to}`}
    onClick={onClick}
    className="text-white text-base font-medium hover:text-emerald-400 transition-all duration-300 block py-3 px-4 rounded-lg hover:bg-white/10 transform hover:translate-x-2"
  >
    {children}
  </a>
)
