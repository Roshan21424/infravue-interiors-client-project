"use client"
import { useState, useCallback, useEffect } from "react"

export default function Projects() {
  const projects = [
    {
      id: "p2",
      title: "NxtWave Institute Of Advanced Technology",
      description: "40,000 sq.ft Site At Chevella.",
      images: [
        "/Images/Projects/NIAT/1.jpg",
        "/Images/Projects/NIAT/2.jpg",
        "/Images/Projects/NIAT/3.jpg",
        "/Images/Projects/NIAT/4.jpg",
      ],
    },
    {
      id: "p1",
      title: "First Source",
      description: "40,000 sq.ft Site At Kondapur.",
      images: [
        "/Images/Projects/firstSource/1.jpg",
        "/Images/Projects/firstSource/2.jpg",
        "/Images/Projects/firstSource/3.jpg",
        "/Images/Projects/firstSource/4.jpg",
        "/Images/Projects/firstSource/5.jpg",
        "/Images/Projects/firstSource/6.jpg",
        "/Images/Projects/firstSource/7.jpg",
        "/Images/Projects/firstSource/8.jpg",
        "/Images/Projects/firstSource/9.jpg",
        "/Images/Projects/firstSource/10.jpg",
        "/Images/Projects/firstSource/11.jpg",
        "/Images/Projects/firstSource/12.jpg",
        "/Images/Projects/firstSource/13.jpg",
        "/Images/Projects/firstSource/14.jpg",
      ],
    },
    {
      id: "p3",
      title: "Sesola",
      description: "3,200 SQ.FT Site At Kondapur.",
      images: [
        "/Images/Projects/Sesola/1.jpg",
        "/Images/Projects/Sesola/2.jpg",
        "/Images/Projects/Sesola/3.jpg",
        "/Images/Projects/Sesola/4.jpg",
        "/Images/Projects/Sesola/5.jpg",
        "/Images/Projects/Sesola/6.jpg",
        "/Images/Projects/Sesola/7.jpg",
        "/Images/Projects/Sesola/8.jpg",
      ],
    },
    {
      id: "p5",
      title: "Uncode",
      description: "A 4,000 SQ.FT Site At Kondapur.",
      images: [
        "/Images/Projects/Uncode/1.jpg",
        "/Images/Projects/Uncode/2.jpg",
        "/Images/Projects/Uncode/3.jpg",
        "/Images/Projects/Uncode/4.jpg",
        "/Images/Projects/Uncode/5.jpg",
        "/Images/Projects/Uncode/6.jpg",
      ],
    },
    {
      id: "p6",
      title: "Unisoft",
      description: "A 2,500 SQ.FT site at Hi-Tech City",
      images: [
        "/Images/Projects/Unisoft/1.jpg",
        "/Images/Projects/Unisoft/2.jpg",
        "/Images/Projects/Unisoft/3.jpg",
        "/Images/Projects/Unisoft/4.jpg",
        "/Images/Projects/Unisoft/5.jpg",
        "/Images/Projects/Unisoft/6.jpg",
      ],
    }, {
      id: "p6",
      title: "Unisoft",
      description: "A 2,500 SQ.FT site at Hi-Tech City",
      images: [
        "/Images/Projects/Unisoft/1.jpg",
        "/Images/Projects/Unisoft/2.jpg",
        "/Images/Projects/Unisoft/3.jpg",
        "/Images/Projects/Unisoft/4.jpg",
        "/Images/Projects/Unisoft/5.jpg",
        "/Images/Projects/Unisoft/6.jpg",
      ],
    },
  ]

  const [indices, setIndices] = useState({})
  const [visibleProjects, setVisibleProjects] = useState(5)

  const setIndexFor = useCallback((id, next) => {
    setIndices((prev) => ({ ...prev, [id]: next }))
  }, [])

  const go = useCallback(
    (id, dir, n) => {
      const current = indices[id] ?? 0
      const next = (current + dir + n) % n
      setIndexFor(id, next)
    },
    [indices, setIndexFor],
  )

  const handleViewMore = () => {
    setVisibleProjects((prev) => Math.min(prev + 5, projects.length))
  }

  // helper to compute relative distance
  const dist = (i, index, n) => {
    const raw = i - index
    const half = Math.floor(n / 2)
    return ((raw + n + half) % n) - half
  }

  // 🔥 Auto-scroll effect for each project
  useEffect(() => {
    const visibleProjectsList = projects.slice(0, visibleProjects)
    const timers = visibleProjectsList.map((project) => {
      const n = project.images.length
      return setInterval(() => {
        go(project.id, 1, n) // move right every 3 seconds
      }, 2000)
    })

    return () => timers.forEach(clearInterval)
  }, [projects, go, visibleProjects])

  return (
    <main id="projects" className="flex flex-col items-center py-10 gap-12 bg-gradient-to-b from-gray-50 to-white">
      <div className="mb-6 text-center animate-fade-in-up">
        <div className="inline-block px-6 py-2 rounded-full bg-white/80 backdrop-blur-md border border-gray-200 text-gray-800 text-sm font-medium tracking-wide mb-4 shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105">
          our projects
        </div>
        <h2 className="text-2xl md:text-4xl lg:text-5xl py-2 bg-gradient-to-r from-gray-800 to-gray-600 bg-clip-text text-transparent">
          Showcasing Our <span className="font-extrabold text-[#64E2B7] animate-fade-slide">WORK & CREATIVITY</span>
        </h2>
        <p className="mt-6 max-w-6xl mx-auto text-slate-600 text-lg leading-relaxed px-4">
          A collection of the amazing projects we've delivered — blending design, innovation, and functionality to
          create spaces people love.
        </p>
      </div>

      <div className="w-full px-4 flex flex-col gap-16">
        {projects.slice(0, visibleProjects).map((project, projectIndex) => {
          const n = project.images.length
          const index = indices[project.id] ?? 0

          return (
            <section
              key={project.id}
              className="w-full max-w-[1200px] mx-auto animate-slide-in-up"
              style={{ animationDelay: `${projectIndex * 0.2}s` }}
            >
              <div className="mb-1 text-center">
                <div className="relative inline-block">
                  <span
                    className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 
                     text-[120px] md:text-[200px] font-extrabold text-[#FFDE63] 
                     opacity-50 select-none pointer-events-none -z-10 leading-none"
                  >
                    {projectIndex + 1}
                  </span>
                  <h2
                    className="relative text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-extrabold uppercase 
                   text-[#FF0066] mb-1 cursor-default px-4"
                  >
                    {project.title}
                  </h2>
                </div>
                <p className="text-lg md:text-xl text-gray-600 font-medium px-4">{project.description}</p>
              </div>

              <div className="relative h-[300px] sm:h-[350px] md:h-[450px] my-2 overflow-visible">
                {project.images.map((img, i) => {
                  const d = dist(i, index, n)
                  if (Math.abs(d) > 1) return null

                  const scale = d === 0 ? 1 : 0.85
                  const offset = d * (window.innerWidth < 768 ? 200 : 300)
                  const z = 100 - Math.abs(d)
                  const isActive = d === 0

                  return (
                    <article
                      key={`${project.id}-${i}`}
                      className="absolute top-1/2 left-1/2 w-[240px] sm:w-[280px] md:w-[520px] h-[160px] sm:h-[200px] md:h-[340px] rounded-xl shadow-2xl transition-all duration-500 ease-out bg-cover bg-center cursor-pointer hover:shadow-3xl group"
                      style={{
                        zIndex: z,
                        transform: `translate(-50%, -50%) translateX(${offset}px) scale(${scale})`,
                        backgroundImage: `url(${img})`,
                        filter: isActive ? "none" : "brightness(0.7) saturate(0.8)",
                      }}
                      onClick={() => (isActive ? null : go(project.id, d > 0 ? 1 : -1, n))}
                    >
                      <div className="absolute inset-0 bg-black/20 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                        {!isActive && (
                          <div className="text-white text-xs sm:text-sm font-medium bg-black/50 px-3 sm:px-4 py-2 rounded-full">
                            Click to view
                          </div>
                        )}
                      </div>
                    </article>
                  )
                })}
              </div>

              <div className="flex items-center justify-center gap-4 sm:gap-8 select-none">
                <button
                  className="w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-white shadow-lg border border-gray-200 text-gray-600 text-xl sm:text-2xl hover:text-[#FF0066] hover:shadow-xl hover:scale-110 transition-all duration-300 flex items-center justify-center"
                  onClick={() => go(project.id, -1, n)}
                >
                  ‹
                </button>

                <div className="flex gap-2">
                  {project.images.map((_, i) => (
                    <button
                      key={i}
                      className={`w-2 h-2 sm:w-3 sm:h-3 rounded-full transition-all duration-300 ${
                        i === index ? "bg-[#FF0066] scale-125" : "bg-gray-300 hover:bg-gray-400"
                      }`}
                      onClick={() => setIndexFor(project.id, i)}
                    />
                  ))}
                </div>

                <button
                  className="w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-white shadow-lg border border-gray-200 text-gray-600 text-xl sm:text-2xl hover:text-[#FF0066] hover:shadow-xl hover:scale-110 transition-all duration-300 flex items-center justify-center"
                  onClick={() => go(project.id, 1, n)}
                >
                  ›
                </button>
              </div>
            </section>
          )
        })}
      </div>

      {visibleProjects < projects.length && (
        <div className="mt-8 text-center">
          <button
            onClick={handleViewMore}
            className="px-8 py-4 bg-gradient-to-r from-[#FF0066] to-[#FF3366] text-white font-semibold rounded-full shadow-lg hover:shadow-xl hover:scale-105 transition-all duration-300 text-lg"
          >
            View More Projects
          </button>
        </div>
      )}
    </main>
  )
}
