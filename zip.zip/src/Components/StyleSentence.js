"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"

const items = [
  { id: "classic", label: "Classic", description: "Timeless Elegance & Tradition.", font: "font-classic" },
  {
    id: "minimalist",
    label: "Minimalist",
    description: "Simplicity, Calm, & Clutter-Free Spaces.",
    font: "font-minimalist",
  },
  {
    id: "industrial",
    label: "Industrial",
    description: "Raw Textures, Bold Lines & Edgy Vibes.",
    font: "font-industrial",
  },
  { id: "modern", label: "Modern", description: "Clean Lines & Contemporary Comfort.", font: "font-modern" },
  {
    id: "contemporary",
    label: "Contemporary",
    description: "Trendy Designs That Are Functional.",
    font: "font-contemporary",
  },
  { id: "luxury", label: "Luxury", description: "Opulent, High-End Interiors With Wow Factor.", font: "font-luxury" },
]

// Font mappings (Tailwind custom classes)
const fontClasses = {
  "font-classic": "font-['Cormorant_Garamond']", // Elegant serif
  "font-minimalist": "font-['Work_Sans']", // Minimal & clean
  "font-industrial": "font-['Bebas_Neue']", // Raw, bold, factory-style
  "font-modern": "font-['Raleway']", // Stylish, balanced modern
  "font-contemporary": "font-['Quicksand']", // Trendy & approachable
  "font-luxury": "font-['Trajan_Pro']",
}

const letterVariants = {
  hidden: { opacity: 0, y: 50 },
  visible: { opacity: 1, y: 0 },
}

export default function StyleSentence() {
  const [index, setIndex] = useState(0)

  useEffect(() => {
    const interval = setInterval(() => setIndex((i) => (i + 1) % items.length), 2000)
    return () => clearInterval(interval)
  }, [])

  const current = items[index]

  return (
    <div className="my-8 sm:my-12 lg:my-16 flex flex-col items-center gap-4 sm:gap-6 max-w-6xl mx-auto text-center px-4">
      {/* First line */}
      <h1 className="text-xl sm:text-2xl lg:text-3xl font-economica font-extrabold">
        Choose The{" "}
        <span className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl uppercase font-extrabold block sm:inline">
          Style & Theme
        </span>{" "}
        <span className="block sm:inline">you Wish</span>
      </h1>

      {/* Animated Style Label */}
      <div className="inline-flex gap-0 overflow-hidden">
        {current.label.split("").map((letter, i) => (
          <motion.span
            key={letter + i + current.id}
            className={`text-4xl sm:text-6xl md:text-7xl lg:text-8xl xl:text-9xl uppercase font-bold tracking-tighter text-[#FF0066] ${fontClasses[current.font]}`}
            variants={letterVariants}
            initial="hidden"
            animate="visible"
            transition={{ delay: i * 0.05, duration: 0.5 }}
          >
            {letter}
          </motion.span>
        ))}
      </div>

      {/* Optional Description */}
      <p className="text-sm sm:text-base lg:text-lg text-gray-600 text-center max-w-2xl">{current.description}</p>
    </div>
  )
}
